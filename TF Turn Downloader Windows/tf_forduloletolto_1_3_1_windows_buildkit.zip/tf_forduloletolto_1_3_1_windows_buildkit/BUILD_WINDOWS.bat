@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title TF Forduloletolto 1.3.1 - Windows build

echo ==================================================
echo TF Forduloletolto 1.3.1 - Windows EXE build
 echo ==================================================
where py >nul 2>nul
if not errorlevel 1 (
  set "PY=py -3.12"
) else (
  where python >nul 2>nul
  if errorlevel 1 goto :nopython
  set "PY=python"
)

%PY% -c "import tkinter, struct; assert struct.calcsize('P') == 8"
if errorlevel 1 goto :nopython

if not exist ".venv\Scripts\python.exe" (
  echo [1/5] Virtualis kornyezet letrehozasa...
  %PY% -m venv .venv
  if errorlevel 1 goto :error
)
set "VPY=%CD%\.venv\Scripts\python.exe"
echo [2/5] Fuggosegek telepitese...
"%VPY%" -m pip install --disable-pip-version-check -r requirements-build.txt
if errorlevel 1 goto :error

echo [3/5] Windows EXE forditasa...
"%VPY%" -m PyInstaller --noconfirm --clean --onedir --windowed --name TF_Forduloletolto_1_3_1 --collect-all playwright --collect-all truststore --collect-all certifi --hidden-import tkinter --hidden-import tkinter.ttk gui.py
if errorlevel 1 goto :error

echo [4/5] Chromium letoltese a terjesztheto mappaba...
set "PLAYWRIGHT_BROWSERS_PATH=%CD%\dist\TF_Forduloletolto_1_3_1\browsers"
"%VPY%" -m playwright install chromium
if errorlevel 1 goto :error

echo [5/5] Ellenorzes...
if not exist "dist\TF_Forduloletolto_1_3_1\TF_Forduloletolto_1_3_1.exe" goto :error
if not exist "dist\TF_Forduloletolto_1_3_1\browsers" goto :error
copy /Y "README_FELHASZNALOKNAK.txt" "dist\TF_Forduloletolto_1_3_1\OLVASS_EL.txt" >nul

echo.
echo Terjesztheto ZIP keszitese...
"%VPY%" -c "import shutil; shutil.make_archive('TF_Forduloletolto_1_3_1_Windows', 'zip', 'dist', 'TF_Forduloletolto_1_3_1')"
if errorlevel 1 goto :error
echo SIKERES BUILD!
echo Terjesztheto mappa: dist\TF_Forduloletolto_1_3_1
echo A TELJES mappat ZIP-eld, ne csak az EXE-t!
echo Inditas: dist\TF_Forduloletolto_1_3_1\TF_Forduloletolto_1_3_1.exe
echo.
pause
exit /b 0
:nopython
echo HIBA: Python 3.12 64 bit vagy Tkinter nincs telepitve vagy nem talalhato a PATH-ban.
echo Telepites: https://www.python.org/downloads/windows/
pause
exit /b 1
:error
echo.
echo HIBA: A build megszakadt. Olvasd el a fenti hibauzenetet.
pause
exit /b 1
