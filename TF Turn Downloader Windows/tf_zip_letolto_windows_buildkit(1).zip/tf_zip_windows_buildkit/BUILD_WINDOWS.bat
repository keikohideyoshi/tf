@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title TF ZIP Letolto - Windows build

echo ==================================================
echo TF ZIP Letolto - Windows EXE build
 echo ==================================================
where py >nul 2>nul
if not errorlevel 1 (
  set "PY=py -3"
) else (
  where python >nul 2>nul
  if errorlevel 1 goto :nopython
  set "PY=python"
)

if not exist ".venv\Scripts\python.exe" (
  echo [1/5] Virtualis kornyezet letrehozasa...
  %PY% -m venv .venv
  if errorlevel 1 goto :error
)
set "VPY=%CD%\.venv\Scripts\python.exe"
echo [2/5] Fuggosegek telepitese...
"%VPY%" -m pip install --disable-pip-version-check -r requirements-build.txt
if errorlevel 1 goto :error

echo [3/5] Windows EXE forditasa...
"%VPY%" -m PyInstaller --noconfirm --clean --onedir --windowed --name TF_ZIP_Letolto --collect-all playwright --hidden-import tkinter --hidden-import tkinter.ttk gui.py
if errorlevel 1 goto :error

echo [4/5] Chromium letoltese a terjesztheto mappaba...
set "PLAYWRIGHT_BROWSERS_PATH=%CD%\dist\TF_ZIP_Letolto\browsers"
"%VPY%" -m playwright install chromium
if errorlevel 1 goto :error

echo [5/5] Ellenorzes...
if not exist "dist\TF_ZIP_Letolto\TF_ZIP_Letolto.exe" goto :error
if not exist "dist\TF_ZIP_Letolto\browsers" goto :error
copy /Y "README_FELHASZNALOKNAK.txt" "dist\TF_ZIP_Letolto\OLVASS_EL.txt" >nul

echo.
echo SIKERES BUILD!
echo Terjesztheto mappa: dist\TF_ZIP_Letolto
echo A TELJES mappat ZIP-eld, ne csak az EXE-t!
echo Inditas: dist\TF_ZIP_Letolto\TF_ZIP_Letolto.exe
echo.
pause
exit /b 0
:nopython
echo HIBA: Python 3 nincs telepitve vagy nem talalhato a PATH-ban.
echo Telepites: https://www.python.org/downloads/windows/
pause
exit /b 1
:error
echo.
echo HIBA: A build megszakadt. Olvasd el a fenti hibauzenetet.
pause
exit /b 1
