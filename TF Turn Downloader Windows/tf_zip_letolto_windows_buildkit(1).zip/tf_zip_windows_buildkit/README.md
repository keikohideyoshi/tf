# TF ZIP Letöltő – Windows buildkit

A Linuxon bevált 1.2-es alkalmazás Windowsra igazított forráskódja és egykattintásos buildkészlete.

## Build Windows 10/11 (64 bit) rendszeren

1. Telepíts **64 bites Python 3.11–3.13** verziót a python.org-ról, és jelöld be az **Add python.exe to PATH** lehetőséget.
2. Csomagold ki ezt a buildkitet egy egyszerű útvonalra, például `C:\TFBuild`.
3. Duplán kattints a **BUILD_WINDOWS.bat** fájlra. Internetkapcsolat szükséges.
4. A kész alkalmazás: `dist\TF_ZIP_Letolto\TF_ZIP_Letolto.exe`.
5. **A teljes `dist\TF_ZIP_Letolto` mappát** csomagold ZIP-be és oszd meg, ne csak az EXE-t.

A build automatikusan külön `.venv` környezetet használ, telepíti a Python-függőségeket, PyInstallerrel lefordítja a programot, és a szükséges Chromium böngészőt is az alkalmazás mellé tölti. Az elkészült csomag használatához **nem kell Python, pip vagy Playwright telepítés**. A csomag a Chromium miatt nagy méretű lehet.

## Működés

- **ZIP-ek letöltése + HTML**: böngészős belépés, ZIP-ek letöltése és HTML-ek kigyűjtése.
- **HTML-ek kigyűjtése**: korábbi ZIP-ek feldolgozása offline.
- Alapértelmezett mappa: `%USERPROFILE%\Downloads\TF\TF3042`; tallózással módosítható.
- A böngészőprofil a `%LOCALAPPDATA%\TFZipLetolto\browser-profile` mappában marad, nem kerül a terjesztett csomagba.

## Fontos

- A Windows EXE-t **Windowson kell buildelni**; ez a Linuxos környezetben előkészített buildkit, nem kész Windows bináris.
- Az alkalmazás *onedir* formátumú: van egy futtatható EXE, de szüksége van a mellé csomagolt `_internal` és `browsers` mappákra.
- A build első alkalommal hosszabb ideig tart és internetet igényel.
- Windows SmartScreen ismeretlen kiadót jelezhet, mert az EXE nincs kódaláírva.
- A Beholder letöltési felületének esetleges változásai módosítást tehetnek szükségessé.
- A Windowsos működést ezen a Linuxos környezeten nem lehetett végponttól végpontig tesztelni.
