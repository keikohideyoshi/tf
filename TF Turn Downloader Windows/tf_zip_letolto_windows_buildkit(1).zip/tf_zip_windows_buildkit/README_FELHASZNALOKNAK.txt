TF ZIP LETOLTO - WINDOWS

1. Csomagold ki a teljes TF_ZIP_Letolto mappat.
2. Inditsd a TF_ZIP_Letolto.exe fajlt.
3. A ZIP-ek alapertelmezett helye: Downloads\TF\TF3042.
4. A HTML-ek a valasztott ZIP mappa HTML almappajaba kerulnek.
5. A Beholder oldalon a sajat fiokodba jelentkezz be.

FONTOS: A browsers es _internal mappaknak az EXE mellett kell maradniuk.
A program nem kuld bejelentkezesi adatokat a keszitonek.
A bongeszoprofil a LOCALAPPDATA\TFZipLetolto mappaban marad.
Csak megbizhato forrasbol szarmazo csomagot futtass.
