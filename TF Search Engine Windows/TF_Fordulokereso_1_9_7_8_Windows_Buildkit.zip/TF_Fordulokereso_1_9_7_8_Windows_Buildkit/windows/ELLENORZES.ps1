$ErrorActionPreference = 'Continue'
Write-Host 'Windows build ellenorzes' -ForegroundColor Cyan
Write-Host ('Windows: ' + [Environment]::OSVersion.VersionString)
Write-Host ('64 bit: ' + [Environment]::Is64BitOperatingSystem)
$exe=Join-Path $PSScriptRoot 'TF_Fordulokereso.exe'
Write-Host ('EXE: ' + (Test-Path $exe))
Write-Host ('Enciklopediak: ' + (Test-Path (Join-Path $PSScriptRoot 'data/reference/Varázslatok összefoglaló.html')))
try { $r=Invoke-RestMethod 'http://127.0.0.1:11434/api/tags' -TimeoutSec 3; Write-Host 'Ollama API: OK'; $r.models | ForEach-Object { Write-Host (' - ' + $_.name) } }
catch { Write-Host 'Ollama API: NEM ELERHETO (az alapkereses ettol meg mukodik)' }
