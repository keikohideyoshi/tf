@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Ollama_Seged.ps1"
pause
