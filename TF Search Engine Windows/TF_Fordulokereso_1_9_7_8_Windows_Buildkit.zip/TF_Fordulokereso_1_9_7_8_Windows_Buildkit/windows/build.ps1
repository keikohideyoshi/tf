param([switch]$SkipTests)
$ErrorActionPreference = 'Stop'
$Root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
Set-Location $Root
function Fail($Message) { Write-Host "HIBA: $Message" -ForegroundColor Red; exit 1 }
if (-not [Environment]::Is64BitOperatingSystem) { Fail '64 bites Windows szükséges.' }
$Python = $null
if (Get-Command py -ErrorAction SilentlyContinue) { & py -3 -c 'import sys; print(sys.version)' ; if ($LASTEXITCODE -eq 0) { $Python = 'py' } }
if (-not $Python -and (Get-Command python -ErrorAction SilentlyContinue)) { $Python = 'python' }
if (-not $Python) { Fail 'Python 3 nincs telepítve. Telepítsd: https://www.python.org/downloads/windows/' }
if (-not (Test-Path '.venv-build/Scripts/python.exe')) {
 Write-Host 'Build virtualis kornyezet letrehozasa...'
 if ($Python -eq 'py') { & py -3 -m venv .venv-build } else { & python -m venv .venv-build }
 if ($LASTEXITCODE -ne 0) { Fail 'Nem sikerult a venv letrehozasa.' }
}
$Vpy = Join-Path $Root '.venv-build/Scripts/python.exe'
& $Vpy -m pip install --upgrade pip
if ($LASTEXITCODE -ne 0) { Fail 'pip frissites sikertelen.' }
& $Vpy -m pip install -r requirements.txt 'pyinstaller>=6,<7'
if ($LASTEXITCODE -ne 0) { Fail 'Fuggosegek telepitese sikertelen.' }
if (-not $SkipTests) {
 & $Vpy -m unittest discover -s tests -p 'test_*.py'
 if ($LASTEXITCODE -ne 0) { Fail 'Automatikus tesztek sikertelenek.' }
}
& $Vpy -m PyInstaller --noconfirm --clean --onedir --windowed --name TF_Fordulokereso --paths "$Root/app" --collect-submodules bs4 --collect-submodules lxml --add-data "$Root/app/tf_dictionary.json;." "$Root/windows/entry.py"
if ($LASTEXITCODE -ne 0) { Fail 'PyInstaller build sikertelen.' }
$Dest = Join-Path $Root 'dist/TF_Fordulokereso'
New-Item -ItemType Directory -Force (Join-Path $Dest 'data/reference') | Out-Null
Copy-Item 'data/reference/*.html' (Join-Path $Dest 'data/reference/') -Force
Copy-Item 'windows/Ollama_Seged.ps1' (Join-Path $Dest 'Ollama_Seged.ps1') -Force
Copy-Item 'windows/Ollama_Seged.cmd' (Join-Path $Dest 'Ollama_Seged.cmd') -Force
Copy-Item 'windows/ELLENORZES.ps1' (Join-Path $Dest 'ELLENORZES.ps1') -Force
Copy-Item 'windows/README_WINDOWS.md' (Join-Path $Dest 'README_WINDOWS.md') -Force
New-Item -ItemType Directory -Force (Join-Path $Dest 'data') | Out-Null
New-Item -ItemType Directory -Force (Join-Path $Dest 'logs') | Out-Null
$Zip = Join-Path $Root 'dist/TF_Fordulokereso_Windows_1_9_7_8.zip'
if (Test-Path $Zip) { Remove-Item $Zip -Force }
Compress-Archive -Path $Dest -DestinationPath $Zip -CompressionLevel Optimal
Write-Host "KESZ: $Zip" -ForegroundColor Green
Write-Host 'Fontos: az Ollama kulon telepitendo, a modell nem resze az EXE-nek.'
