$ErrorActionPreference = 'Stop'
$Model = 'qwen3:1.7b'
$Official = 'https://ollama.com/download/OllamaSetup.exe'
$Api = 'http://127.0.0.1:11434'
function Info($s) { Write-Host $s -ForegroundColor Cyan }
function Find-Ollama {
 $cmd = Get-Command ollama.exe -ErrorAction SilentlyContinue
 if ($cmd) { return $cmd.Source }
 $local = Join-Path $env:LOCALAPPDATA 'Programs\Ollama\ollama.exe'
 if (Test-Path $local) { return $local }
 return $null
}
function Api-Ready {
 try { $r=Invoke-RestMethod -Uri "$Api/api/tags" -TimeoutSec 3; return $true } catch { return $false }
}
function Wait-ForApi([int]$Seconds) {
 for ($i=0;$i -lt $Seconds;$i+=2) {
  if (Api-Ready) { return $true }
  Start-Sleep -Seconds 2
 }
 return $false
}
Info 'TF Fordulokereso - Ollama Windows seged'
Info 'Az Ollama a programtol fuggetlen, hivatalos Windows alkalmazas.'
$exe=Find-Ollama
if (-not $exe) {
 Info "Hivatalos telepito: $Official"
 $answer=Read-Host 'Letoltsuk es elinditsuk a hivatalos OllamaSetup.exe telepitot? (I/N)'
 if ($answer -notmatch '^[IiYy]') { Info 'A telepites kihagyva.'; exit 0 }
 $installer=Join-Path $env:TEMP 'TF_OllamaSetup.exe'
 Info 'Letoltes HTTPS kapcsolaton...'
 Invoke-WebRequest -Uri $Official -OutFile $installer -UseBasicParsing
 $sig=Get-AuthenticodeSignature -FilePath $installer
 if ($sig.Status -ne 'Valid') { throw "A telepito digitalis alairasa nem ervenyes ($($sig.Status)). Nem indul el." }
 Info "Digitalis alairas ellenorizve: $($sig.SignerCertificate.Subject)"
 Info 'Telepito elinditasa. A telepiteshez kovesse a Windows ablak utasitasait.'
 $proc=Start-Process -FilePath $installer -PassThru -Wait
 if ($proc.ExitCode -ne 0) { Write-Warning "Telepito kilepesi kod: $($proc.ExitCode)" }
 $exe=Find-Ollama
 if (-not $exe) { throw 'Az Ollama.exe nem talalhato. Inditsd ujra a PowerShellt es ellenorizd a telepitest.' }
}
Info "Ollama.exe: $exe"
if (-not (Api-Ready)) {
 Info 'Ollama API nem elerheto; megprobaljuk elinditani az alkalmazast.'
 $gui=Join-Path (Split-Path $exe -Parent) 'ollama app.exe'
 if (Test-Path $gui) { Start-Process -FilePath $gui | Out-Null }
 elseif (Test-Path (Join-Path (Split-Path $exe -Parent) 'Ollama.exe')) { Start-Process -FilePath (Join-Path (Split-Path $exe -Parent) 'Ollama.exe') | Out-Null }
 if (-not (Wait-ForApi 30)) {
  Write-Warning 'Az API nem indult el automatikusan. Inditsd az Ollamat a Start menubol, majd futtasd ujra a segedet.'
  exit 1
 }
}
Info 'Ollama API mukodik a 127.0.0.1:11434 cimen.'
$tags=Invoke-RestMethod -Uri "$Api/api/tags" -TimeoutSec 10
$found=@($tags.models | Where-Object { $_.name -eq $Model -or $_.model -eq $Model }).Count -gt 0
if ($found) { Info "A modell mar telepitve: $Model" }
else {
 Info "Javasolt modell: $Model. Letoltese kb. 1-2 GB tarhelyet igenyelhet."
 $answer=Read-Host 'Letoltsuk a modellt? (I/N)'
 if ($answer -match '^[IiYy]') {
  & $exe pull $Model
  if ($LASTEXITCODE -ne 0) { throw "Modellletoltes sikertelen: $LASTEXITCODE" }
 } else { Info 'Modell letoltese kihagyva.' }
}
Info 'Kesz. A TF Fordulokeresoben: AI beallitasok -> Modell -> Allapot ellenorzese.'
