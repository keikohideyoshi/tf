# TF Fordulókereső 1.9.7.8 – Windows buildkit

## Cél

Windows 10 22H2 vagy újabb, 64 bites Windows rendszer alatt **önállóan futtatható EXE** készítése az eredeti 1.9.7.8-as forrásból. A build **Windows gépen futtatandó**: a PyInstaller nem keresztfordító.

## Készítés (a Windows-gépen)

1. Csomagold ki ezt a ZIP-et.
2. Telepítsd a **Python 3-at** a https://www.python.org/downloads/windows/ oldalról, ha még nincs telepítve. A `py` parancs legyen elérhető.
3. Kattints duplán a **`windows/BUILD_WINDOWS.cmd`** fájlra. A script elkülönített `.venv-build` környezetet hoz létre, telepíti a függőségeket, lefuttatja a teszteket, majd PyInstallerrel összeállítja a programot.
4. Kimenet: `dist/TF_Fordulokereso/TF_Fordulokereso.exe` és a továbbadható `dist/TF_Fordulokereso_Windows_1_9_7_8.zip`.
5. A **teljes `TF_Fordulokereso` mappát** kell továbbadni, nem csak az EXE-t! A mellékelt `_internal` könyvtár és a `data/reference` enciklopédiák is szükségesek.

A végfelhasználónak **nem kell Python**, csak a kicsomagolt program. Az első importálás előtt győződj meg arról, hogy a mappa írható (ne a `Program Files` védett mappába másold). A helyi adatbázis a program mappájában, `data/tudasbazis.sqlite3` néven jön létre.

## Ollama: telepítés és modell letöltése

Az Ollama **nem része** az EXE-nek, és a modell sem. Ennek oka a méret, a frissíthetőség és az eltérő GPU-konfigurációk.

1. A program mellől futtasd az **`Ollama_Seged.cmd`** fájlt, vagy a program **AI beállítások → Ollama telepítése** gombját.
2. A segéd **külön jóváhagyást kér**, majd a hivatalos `https://ollama.com/download/OllamaSetup.exe` címről tölti le a Windows-telepítőt. A telepítő digitális aláírását ellenőrzi; sikertelen ellenőrzés esetén **nem indítja el**.
3. A telepítőt a Windows normál telepítőablakában kell végigkattintani.
4. A segéd ellenőrzi a helyi Ollama API-t: `http://127.0.0.1:11434/api/tags`. Szükség esetén próbálja elindítani az alkalmazást. Ha ez nem sikerül, indítsd az Ollamát a Start menüből, majd futtasd újra a segédet.
5. A segéd külön rákérdez a **`qwen3:1.7b`** modell letöltésére. A letöltés internetet és további lemezterületet igényel.
6. A TF Fordulókeresőben: **AI beállítások → Állapot ellenőrzése**, majd a modell beállítása `qwen3:1.7b` értékre. Szükség esetén indítsd újra a Fordulókeresőt.

**A Fordulókereső Ollama nélkül is használható.** Az Ollama a természetes nyelvű kérdés értelmezését támogatja; a fordulók feldolgozása és a keresés helyben történik.

### Hibakeresés

- `Ollama nem érhető el`: indítsd az Ollamát a Start menüből; ellenőrizd, hogy a `http://127.0.0.1:11434/api/tags` válaszol-e.
- `Modell nem elérhető`: futtasd az `Ollama_Seged.cmd` fájlt, vagy az Ollama telepítése után egy új PowerShell ablakban: `ollama pull qwen3:1.7b`.
- A programban a modell letöltése után az állapot frissítése néhány másodpercet igényelhet.
- Az Ollama nem szükségszerűen használja a GPU-t; CPU-n is futhat, lassabban.
- Ollama Windows naplók: `%LOCALAPPDATA%\Ollama`.
- Az adatbázist **bezárt program mellett** mentsd.
- Ha a forrásfordulókat áthelyezed, a korábban tárolt elérési utak érvénytelenné válhatnak.
- Futtasd az **`ELLENORZES.ps1`** fájlt a kicsomagolt EXE mellől, ha ellenőrizni akarod a fájlokat és az API-t.

## Ellenőrzött és nem ellenőrzött

A buildkit forráskódját és a Python-fájlok szintaxisát Linuxon ellenőriztük. A **Windowsos PyInstaller buildet és az EXE futását tényleges Windows gépen kell tesztelni**. A build során a mellékelt tesztek automatikusan lefutnak; sikertelen teszt esetén a build megáll.

## Források

- Ollama Windows: https://github.com/ollama/ollama/blob/main/docs/windows.mdx
- Ollama telepítő: https://ollama.com/download/OllamaSetup.exe
- PyInstaller: https://pyinstaller.org/
