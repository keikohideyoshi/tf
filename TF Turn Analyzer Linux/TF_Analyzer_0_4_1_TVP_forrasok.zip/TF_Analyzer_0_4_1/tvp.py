"""TF Analyzer 0.4.1: TVP események a megőrzött HTML-ből.
A régi szöveges elemző csak HTML nélküli fordulókhoz használatos.
"""
import re
from bs4 import BeautifulSoup, NavigableString, Tag

GAIN_NUM = re.compile(r'\+\s*(\d+)\s*TVP\b|kaptál\s+(\d+)\s*TVP-t|előállítottál\s+(\d+)\s*TVP-t',re.I)
SPEND_NUM = re.compile(r'(\d+)\s*pontot használtál fel,\s*van még\s*(\d+)',re.I)
SAFFRON = re.compile(r'Összemorzsolod\s+a\s+sáfránykövet\.\s*(\d+)\s*tevékenységpontot\s+kaptál',re.I)
KP = re.compile(r'^\*\s*(\d+)\.\s*KP:\s*(.*)$',re.I)
SAFFRON_POWDER = re.compile(r'(?:használod\s+a\s+211\.\s+tárgyat\s*\(\s*sáfránypor\s*\)|Belélegzel\s+némi\s+sáfrányport)',re.I)
PSI_MEDITATION = re.compile(r'Elmerülsz\s+egy\s+rövid\s+időre\s+agyad\s+legmélyebb\s+bugyraiban',re.I)
COMMAND = re.compile(r'^(vv|tf|mak|kld|sze|be|lm|h|e|v|p|k|gy|sz|ki|fel|le)\s+\d+',re.I)

def classify(context,kind,amount=None):
    # Csak közeli, konkrét szöveges bizonyíték alapján rendelünk forrást.
    # Az összeg egyezése is feltétel, nehogy egy korábbi parancsra hivatkozzunk.
    if kind=='Bevétel':
        nearby=context[-320:]
        if amount == 5 and SAFFRON_POWDER.search(nearby): return 'Sáfránypor (#211)'
        if amount == 20 and PSI_MEDITATION.search(nearby): return 'Pszi meditáció'
    s=context[-190:].casefold()
    if 'sáfrányk' in s: return 'Sáfránykő'
    if 'időtorzítás' in s: return 'Időtorzítás'
    if 'időt cserélsz' in s: return 'Időcsere'
    if 'meditál' in s: return 'Meditáció'
    if 'spektroszkóp' in s: return 'Moa spektroszkóp'
    if 'sztázisrelikvia' in s: return 'Sztázisrelikvia'
    if kind=='Kiadás': return 'Parancs / tevékenység (ellenőrizendő)'
    return 'Egyéb / ellenőrizendő'

def analyze_html(html):
    """DOM sorrendben dolgozik; egy tvpkap/tvpkolt span pontosan egy esemény.
    A beágyazott vpkap nem TVP. A sáfránykő szöveges kivétel.
    """
    soup=BeautifulSoup(html,'html.parser')
    for t in soup(['script','style','noscript']):t.decompose()
    body=soup.body or soup
    records=[]; recent=[]; kp='Forduló eleje';command='Ismeretlen';previous_balance=None
    # A p.parancs elején lévő táblázat első cellája az adott parancs.
    active_p=None
    def context():return ' '.join(recent)[-550:]
    def add(kind,amount,balance,evidence,method,ctx):
        nonlocal previous_balance
        quality='HTML jelölés' if method=='HTML' else 'Sáfránykő szöveges kivétel'
        if kind=='Kiadás' and previous_balance is not None and balance is not None:
            # A köztes TVP-bevételt is beleszámítjuk az egyenlegváltozásba.
            if previous_balance-(-amount)!=balance: quality+='; egyenleg ellenőrizendő'
        records.append(dict(line=None,kind=kind,amount=amount,balance=balance,
            category=(command.split()[0].upper() if kind=='Kiadás' and command!='Ismeretlen' else classify(ctx,kind,amount)),kp=kp,command=command,quality=quality,
            evidence=evidence[:500],context=ctx[:550],method=method))
        if balance is not None: previous_balance=balance
        elif kind=='Bevétel' and previous_balance is not None:previous_balance+=amount
    for node in body.descendants:
        if isinstance(node,Tag):
            if node.name=='p' and node is not active_p:
                active_p=node
                tbl=node.find('table',class_='par',recursive=False)
                if tbl:
                    cell=tbl.find('td')
                    if cell:
                        label=cell.get_text(' ',strip=True)
                        if COMMAND.match(label):command=label
            if node.name=='span':
                classes=node.get('class') or []
                if 'tvpkap' in classes:
                    value=GAIN_NUM.search(node.get_text(' ',strip=True))
                    if value:
                        amount=int(next(x for x in value.groups() if x is not None))
                        add('Bevétel',amount,None,node.get_text(' ',strip=True),'HTML',context())
                elif 'tvpkolt' in classes:
                    match=SPEND_NUM.search(node.get_text(' ',strip=True))
                    if match:
                        amount=int(match.group(1));balance=int(match.group(2))
                        add('Kiadás',-amount,balance,node.get_text(' ',strip=True),'HTML',context())
        elif isinstance(node,NavigableString):
            # A span tartalmát nem tekintjük új TVP eseménynek.
            if node.find_parent('span',class_=['tvpkap','tvpkolt']):continue
            raw=str(node)
            if not raw.strip():continue
            for m in SAFFRON.finditer(raw):
                add('Bevétel',int(m.group(1)),None,m.group(0),'Szöveg',context()+' '+raw[max(0,m.start()-100):m.end()+80])
            clean=' '.join(raw.split())
            if clean:
                recent.append(clean)
                if len(recent)>25:recent=recent[-25:]
                k=KP.match(clean)
                if k:kp=f'{k.group(1)}. KP';command=k.group(2).strip()
    return records

def analyze(text):
    """Régi szöveges tartalék feldolgozás, kizárólag hiányzó HTML esetére."""
    lines=[x.strip() for x in text.splitlines() if x.strip()]
    records=[];kp='Forduló eleje';command='Ismeretlen'
    for i,line in enumerate(lines):
        k=KP.match(line)
        if k:kp=f'{k.group(1)}. KP';command=k.group(2).strip()
        elif COMMAND.match(line):command=line
        for m in SPEND_NUM.finditer(line):
            records.append(dict(line=i+1,kind='Kiadás',amount=-int(m.group(1)),balance=int(m.group(2)),category='Szöveges (ellenőrizendő)',kp=kp,command=command,quality='HTML hiányzik',evidence=line[:500],context=line[:500],method='Szöveg'))
        for m in GAIN_NUM.finditer(line):
            records.append(dict(line=i+1,kind='Bevétel',amount=int(next(x for x in m.groups() if x)),balance=None,category=classify(' '.join(lines[max(0,i-5):i+1]),'Bevétel',int(next(x for x in m.groups() if x))),kp=kp,command=command,quality='HTML hiányzik',evidence=line[:500],context=line[:500],method='Szöveg'))
        for m in SAFFRON.finditer(line):
            records.append(dict(line=i+1,kind='Bevétel',amount=int(m.group(1)),balance=None,category='Sáfránykő',kp=kp,command=command,quality='Szöveges kivétel',evidence=line[:500],context=line[:500],method='Szöveg'))
    return records
