TF ANALYZER 0.4.1 – TVP BEVÉTELI FORRÁSOK FINOMÍTÁSA
===================================================

VÁLTOZÁS A 0.4-HEZ KÉPEST
- HTML tvpkap eseményeknél a megelőző szöveg alapján felismeri:
  * Sáfránypor (#211): +5 TVP, a 211. tárgy használata vagy belégzés szövege
  * Pszi meditáció: +20 TVP, az „Elmerülsz egy rövid időre...” szöveg
- A sáfránykő +100 TVP szöveges kivétele változatlan.
- A tvpkolt HTML-alapú kiadásfeldolgozás változatlan.
- Az összeg a HTML-ből jön; a forrásmegnevezés nem ad újabb TVP-t.
- A 0.3.3-as combat.py fájl BITRE AZONOS a korábban bevált kiadással.
- A forráskategória a korábbi szöveg közelisége alapján becslés;
  a „Környezet” és „Bizonyíték” oszlopban ellenőrizhető.

TESZT – KEIKO HIDEYOSHI 1671. FORDULÓ (MHTML)
- 51 db pszi meditáció: 51 × 20 = 1020 TVP
- 37 db sáfránypor: 37 × 5 = 185 TVP
- 4 db sáfránykő: 4 × 100 = 400 TVP
- 98 felismert TVP-bevételi esemény összesen; további források is vannak.
A 0.4-es kiadásfelismerés korlátai továbbra is fennállnak.

FRISSÍTÉS MEGLÉVŐ TELEPÍTÉSEN
1. Állítsd le a programot (Ctrl+C).
2. Készíts mentést a teljes programkönyvtárról és a tf_analyzer.sqlite3-ról.
3. A ZIP TF_Analyzer_0_4_1 mappájából másold a programfájlokat
   a meglévő TF_Analyzer könyvtáradba, a régieket felülírva.
4. A tf_analyzer.sqlite3 adatbázist NE töröld vagy cseréld le.
5. Indítsd: ./inditas.sh
6. Böngésző: http://localhost:8501

A 0.3.3 vagy 0.4 alatt eltárolt eredeti HTML-t nem kell újra feltölteni.
A TVP fül a tárolt HTML-ből újraszámolja az adatokat.
