TF ANALYZER 0.6.3 – OBSIDIAN (LINUX)
=====================================

ÚJ: HTML/HTM fordulófájlok közvetlen beolvasása a meglévő MHTML/MHT mellett.
Az eredeti HTML-jelölések (encf1, tvpkap, tvpkolt, felt) megmaradnak.
A magyar karakterkódolást a HTML meta charset jelölése alapján, illetve
UTF-8 és régebbi közép-európai kódolásokkal kezeljük.

A 0.6.2-es TVP-elemzés, feltételes kutatás/mászás, Obsidian téma és
harci felismerés változatlan. A feltételes gyógyítás önálló darabszám-
kimutatása még nincs ebben a verzióban; ez külön tervezett fejlesztés.

FRISSÍTÉS
1. Állítsd le a programot (Ctrl+C).
2. Készíts biztonsági másolatot a teljes programkönyvtárról.
3. Másold át a ZIP fájljait a jelenlegi programkönyvtárba.
4. A tf_analyzer.sqlite3 adatbázist NE töröld és NE írd felül!
5. Indítsd el a ./inditas.sh paranccsal.
6. A feltöltésnél válassz .html, .htm, .mhtml vagy .mht fájlt.

FIGYELEM
A böngésző által mentett HTML mellé tartozó képmappa nem szükséges a
szöveges elemzéshez. Ha egy forduló HTML-jelölései eltérnek, a
feldolgozás eredményét érdemes manuálisan ellenőrizni.
