TF ANALYZER 0.4.3 – TVP-FORRÁSOK FINOMÍTÁSA
===========================================

ÚJ A 0.4.2-HÖZ KÉPEST:
- Reverziós prizma: hatodik szövegvariáns:
  „Pár pillantással visszább kúsztok az időben”.
  Továbbra is csak +1–9 TVP esetén rendelhető hozzá.
- Tudatpont átváltás: második szövegvariáns:
  „Iszonyúan koncentrálsz, ahogy az energiákat transzformálod.”
  Az összeg változó, a tvpkap HTML-elem alapján.
- Zafórion: új bevételi kategória, a „Zafórion” szó közelében
  lévő +10 TVP eseményhez. Egy fordulón belül legfeljebb
  az első ilyen találat kapja meg a Zafórion kategóriát.

A 0.4.2 többi TVP-felismerése változatlan: sáfránypor,
pszi meditáció, sáfránykő, moa spektroszkóp, időtorzítás,
tudatpont átváltás és reverziós prizma. A HTML-es összegek
az elsődlegesek, a szövegek forrást azonosítanak. Az egyes
szövegek közelsége alapján történő besorolás heurisztikus:
ellenőrizd a Bizonyíték és Környezet oszlopokat.

A HARCOK MODUL (combat.py) VÁLTOZATLAN, a 0.3.3-ban
bevált verzió. Az adatbázis szerkezete nem változott.

FRISSÍTÉS:
1. A futó alkalmazást állítsd le a terminálban: Ctrl+C.
2. Készíts biztonsági másolatot a program mappájáról,
   különösen a tf_analyzer.sqlite3 adatbázisról.
3. Csomagold ki ezt a ZIP-et, majd a TF_Analyzer_0_4_3
   mappa fájljait másold a meglévő TF_Analyzer mappába.
4. NE töröld és NE írd felül a tf_analyzer.sqlite3 fájlt.
5. Indítás a megszokott mappában: ./inditas.sh
6. Megnyitás: http://localhost:8501
7. A már importált HTML-es fordulókat nem kell újra feltölteni.

ELLENŐRZÉS: TVP fül – Kategória, Bizonyíték, Környezet.
