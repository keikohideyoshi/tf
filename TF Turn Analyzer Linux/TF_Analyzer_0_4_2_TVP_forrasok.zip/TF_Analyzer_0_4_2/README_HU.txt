TF ANALYZER 0.4.2 – ÚJ TVP-BEVÉTELI FORRÁSOK
===========================================

ÚJ FELISMERÉSEK (az eredeti HTML-ben tárolt TVP-összegekhez):
- Moa spektroszkóp: +10 TVP; a forduló eleji szövegben a „spektorszkóp” alak is elfogadott.
- Időtorzítás: +30 TVP; „Bemetszést végzel az idő szövetén...”
- Tudatpont átváltás: változó TVP; „Gyurmázni kezded az összespórolt tudati energiát.”
- Reverziós prizma: +1–9 TVP; a kronoérintés öt ismert szövegvariánsa.

Az összeget továbbra is a tvpkap HTML elem határozza meg. A szövegminták
csak kategorizálnak, nem generálnak plusz TVP-eseményt. Egy bevételhez
csak egy forrást rendelünk. Ha nincs elég közeli bizonyíték, az esemény
„Egyéb / ellenőrizendő” marad. A sáfránykő szöveges +100 TVP kivétele
megmaradt. A tvpkolt kiadásfeldolgozás és a 0.3.3 harci modul változatlan.

FRISSÍTÉS A 0.4.1-RŐL:
1. A futó programot állítsd le: Ctrl+C.
2. Mentsd el a teljes programkönyvtárat és a tf_analyzer.sqlite3 adatbázist.
3. A ZIP TF_Analyzer_0_4_2 mappájából másold át a programfájlokat a
   meglévő TF_Analyzer könyvtárba, a korábbiakat felülírva.
4. A tf_analyzer.sqlite3 adatbázist NE töröld és NE írd felül.
5. Indítás: ./inditas.sh ; böngésző: http://localhost:8501
6. A korábban eltárolt HTML-es fordulókat nem kell újra feltölteni.

ELLENŐRZÉS: TVP fül, Kategória / Bizonyíték / Környezet oszlopok.
A források hozzárendelése heurisztikus: a közvetlen szövegkörnyezet
számít, nem minden egyedi HTML-szerkezet garantáltan felismerhető.
