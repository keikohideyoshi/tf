TF ANALYZER 0.4 – HTML ALAPÚ TVP, STABIL 0.3.3 HARCI MODULLAL
==============================================================

FRISSÍTÉS MEGLÉVŐ TELEPÍTÉSEN
1. Állítsd le a futó alkalmazást (Ctrl+C).
2. Mentsd el a teljes régi mappát, különösen a tf_analyzer.sqlite3 fájlt.
3. A ZIP TF_Analyzer_0_4 mappájából másold át az app.py, tvp.py,
   parser.py, combat.py, requirements.txt, inditas.sh fájlokat a
   MÁR HASZNÁLT programkönyvtárba, felülírva a régieket.
4. Az adatbázist NE töröld, NE írd felül.
5. A program mappájában: ./inditas.sh
6. A böngészőben: http://localhost:8501

A HTML-t már tartalmazó, 0.3.3-ban importált fordulókat nem kell újra
feltölteni. A TVP fül megnyitáskor újraelemzi a mentett HTML-t.

ÚJ FUNKCIÓK
- TVP-bevétel: <span class="tvpkap"> ... </span>
- TVP-kiadás: <span class="tvpkolt"> ... </span>
- Sáfránykő: "Összemorzsolod a sáfránykövet. N tevékenységpontot kaptál!"
- Beágyazott VP események nem számítanak TVP-nek.
- Eseményenként bizonyíték, megelőző szövegkörnyezet és parancs.
- Forrás/kategória csak előzetes, ellenőrizendő hozzárendelés.
- CSV export, fordulónkénti kimutatás és grafikonok.

A HARCOK MODUL combat.py FÁJLJA VÁLTOZTATÁS NÉLKÜL A 0.3.3-BÓL SZÁRMAZIK.

TESZT (Keiko Hideyoshi 1671. MHTML):
- 94 HTML-es TVP-bevételi esemény
- 738 feldolgozható HTML-es TVP-kiadási esemény
- 4 sáfránykő-esemény (+100 TVP / alkalom)
- 756 tvpkolt elem található összesen, de 18 nem felel meg a
  "N pontot használtál fel, van még M" szövegmintának, ezért
  a jelenlegi verzió nem számolja el őket automatikusan.

FIGYELEM: Az összesített TVP-adatok csak a felismert eseményekre
vonatkoznak. A forrás- és parancs-hozzárendelés közelítő, a teljes
TVP-egyenleg nem garantált. A 18 eltérő formátumot külön vizsgálni kell.
