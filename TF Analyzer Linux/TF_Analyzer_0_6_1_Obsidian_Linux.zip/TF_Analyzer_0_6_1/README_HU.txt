TF ANALYZER 0.6.1 – OBSIDIAN (Linux)
==================================

ÚJ: mélyfekete/éjkék, bronz/türkiz/smaragd arculat és egyedi fantasy fejléc.
Az elemzőmotorok a működő 0.5 verzióval megegyeznek:
combat.py, parser.py és tvp.py változatlan.

TELEPÍTÉS / FRISSÍTÉS
1. Állítsd le a futó TF Analyzert (Ctrl+C).
2. Készíts biztonsági másolatot a teljes jelenlegi mappádról,
   különösen a tf_analyzer.sqlite3 adatbázisról.
3. Másold át a ZIP-ben lévő programfájlokat a jelenlegi mappádba.
   A tf_analyzer.sqlite3 fájlt NE írd felül, NE töröld!
4. Másold át az assets/ és .streamlit/ mappákat is.
5. Indítsd el a korábbi módon: ./inditas.sh
6. Böngészőben: http://localhost:8501

ÚJ TELEPÍTÉS
Python 3 és pip szükséges; a csomag tartalmazza a requirements.txt fájlt.
A ./inditas.sh létrehozza/használja a környezetet a korábbi verzió mintájára.

MEGJEGYZÉS
Az Obsidian téma kizárólag megjelenítési változtatás.
A korábbi adatok megmaradnak, ha az eredeti SQLite-fájlt megtartod.
A fejléc képe az assets/tf_analyzer_obsidian_banner.webp fájlban van.

0.6.1 HIBAJAVÍTÁS
A csatastatisztika az ÉP után opcionális „összes sebzés” és
„összes sebződés” mezőket is tartalmazhat. Mindkét formátum támogatott.
A hiányzó encf1 név továbbra is Ismeretlen jelölést kap.
Ellenőrizve Keiko 1671. (231 csata) és Scott 2887. (516 csata)
fordulóján, HTML-szinkronhiba nélkül.
