TF ANALYZER 0.6.2 – OBSIDIAN (LINUX)
=====================================

ÚJDONSÁGOK
- Szöveges, bronzszínű TF Analyzer fejléc; a képes banner eltávolítva.
- Tudatpont átváltás: két új szövegminta. A TVP összegét továbbra is a tvpkap adja.
- Sztázisrelikvia: "Termel a sztázisrelikvia (+15 TVP)."
  Külön tvpkap nélkül, fordulónként legfeljebb egyszer +15 TVP.
- M mozgás: feltételes kutatás és mászás darabszáma a span.felt HTML-elemekből.
  Külön TVP-költséget NEM számolunk, az M parancs teljes TVP-je változatlan.
- Fordulónkénti mozgási részletezés és CSV-export a TVP fülön.

FRISSÍTÉS 0.6.1-RŐL
1. Állítsd le a programot (Ctrl+C).
2. Készíts biztonsági másolatot a teljes korábbi programkönyvtárról.
3. A ZIP-ben lévő fájlokat másold át a korábbi programkönyvtárba.
4. A tf_analyzer.sqlite3 ADATBÁZIST NE TÖRÖLD ÉS NE ÍRD FELÜL!
5. Indítsd a megszokott ./inditas.sh paranccsal.
6. Nyisd meg: http://localhost:8501

A harci feldolgozó (combat.py) és az MHTML parser (parser.py) változatlan.
Az eredeti MHTML-fordulók újrafeltöltése nem szükséges, ha a HTML már tárolva van.
