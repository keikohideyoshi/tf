@echo off
setlocal
cd /d "%~dp0"
chcp 65001 >nul
where py >nul 2>nul
if %errorlevel%==0 (
    py -3.11 -c "import sys" >nul 2>nul
    if not errorlevel 1 (set "PY=py -3.11") else (set "PY=py -3")
) else (
    set "PY=python"
)
echo.
echo ===== TF Analyzer 0.6.4 - Windows EXE forditas =====
%PY% --version || goto :failed
if not exist ".venv\Scripts\python.exe" (
    %PY% -m venv .venv || goto :failed
)
".venv\Scripts\python.exe" -m pip install --upgrade pip || goto :failed
".venv\Scripts\python.exe" -m pip install -r requirements.txt "pyinstaller>=6.10,<7" || goto :failed
".venv\Scripts\python.exe" -m PyInstaller --noconfirm --clean TF_Analyzer.spec || goto :failed
if not exist "dist\TF_Analyzer_0_6_4_Windows\TF_Analyzer.exe" goto :failed
if not exist "dist\TF_Analyzer_0_6_4_Windows\adatok" mkdir "dist\TF_Analyzer_0_6_4_Windows\adatok"
copy /Y "HASZNALAT_WINDOWS.txt" "dist\TF_Analyzer_0_6_4_Windows\OLVASS_EL.txt" >nul
copy /Y "MENTES_ADATBAZIS.bat" "dist\TF_Analyzer_0_6_4_Windows\MENTES_ADATBAZIS.bat" >nul
echo.
echo KESZ! A terjesztheto program itt van:
echo dist\TF_Analyzer_0_6_4_Windows\TF_Analyzer.exe
echo A teljes TF_Analyzer_0_6_4_Windows mappat masold at!
pause
exit /b 0
:failed
echo.
echo FORDITASI HIBA! Ellenorizd a fenti uzeneteket.
pause
exit /b 1
