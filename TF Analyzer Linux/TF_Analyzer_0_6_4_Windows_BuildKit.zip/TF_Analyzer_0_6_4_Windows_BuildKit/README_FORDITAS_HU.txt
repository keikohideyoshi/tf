TF ANALYZER 0.6.4 - WINDOWS EXE FORDITOKESZLET
===============================================

MIT KAPSZ?
A Linux 0.6.4 teljes forraskodja + PyInstaller Windows onedir build.
A csomag NEM tartalmaz elore leforditott Windows exe-t, mert a Windows
PyInstaller binarist Windows alatt kell elkesziteni.

EGYSZERI ELOKESZITES A WINDOWS GEPEN:
1. Windows 10/11 64 bit, Python 3.11 64 bit (ajanlott) telepitese:
   https://www.python.org/downloads/ (pip + py launcher telepitve).
2. Internet az elso forditashoz, a Python-fuggosegek letoltesehez.
3. Csomagold ki ezt a ZIP-et egy irhato mappaba.
4. Kattints duplan: FORDITAS_WINDOWS.bat
5. Varj: elso alkalommal a telepites es a csomagolas tobb percig tarthat.
6. A kesz mappa: dist\TF_Analyzer_0_6_4_Windows
   Ebben van a TF_Analyzer.exe, _internal es az adatok mappa.
7. Ezt a TELJES mappat atadhatod mas Windows 10/11 64 bites felhasznalonak.
   Nekik mar nem kell Python.

HASZNALAT: a kesz mappaban az OLVASS_EL.txt fajl.

HIBAKERESÉS:
- Ha nincs Python: telepits Python 3.11 64-bit verziot, inditsd ujra a batot.
- Ha a csomagolas hibazik, a konzol kiirja a hibat.
- Ha a program inditasa hibazik, a konzolablakban lathato a traceback.
- A 8501-es portot a Streamlit hasznalja; egyszerre csak egy ilyen peldany fusson.
- Az adatbazist soha ne tedd az _internal mappaba: adatok\tf_analyzer.sqlite3.
- Az Obsidian felulet, HTML/MHTML beolvasas, TVP es harci modulok megmaradtak.

MEGJEGYZES:
A buildet ebben a Linux kornyezetben Windows exe-kent nem lehet
kiprobalni. A Windowsos forditast es elso inditast valodi Windows alatt
kell ellenorizni. Az elkészült exe merete a Streamlit es Plotly miatt
jelentosen nagyobb lesz, mint a forraskod ZIP-je.
