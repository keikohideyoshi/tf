"""TF Analyzer 0.6.4 - Windows portable launcher (PyInstaller onedir)."""
import os
import sys
import threading
import time
import webbrowser
from pathlib import Path

def main():
    frozen = getattr(sys, "frozen", False)
    base = Path(sys.executable).resolve().parent if frozen else Path(__file__).resolve().parent
    bundle = Path(sys._MEIPASS) if frozen else base
    data_dir = base / "adatok"
    data_dir.mkdir(parents=True, exist_ok=True)
    os.environ["TF_ANALYZER_DB"] = str(data_dir / "tf_analyzer.sqlite3")
    os.environ["STREAMLIT_BROWSER_GATHER_USAGE_STATS"] = "false"
    os.environ["STREAMLIT_GLOBAL_DEVELOPMENT_MODE"] = "false"
    os.environ["STREAMLIT_SERVER_HEADLESS"] = "true"
    os.chdir(base)
    from streamlit.web import cli as stcli
    app = bundle / "app.py"
    if not app.is_file():
        raise FileNotFoundError(f"Nem talalhato a program: {app}")
    def browser():
        time.sleep(4)
        webbrowser.open("http://127.0.0.1:8501")
    threading.Thread(target=browser, daemon=True).start()
    sys.argv = ["streamlit", "run", str(app), "--server.address=127.0.0.1", "--server.port=8501", "--server.headless=true", "--browser.gatherUsageStats=false", "--server.fileWatcherType=none", "--server.enableCORS=true", "--server.enableXsrfProtection=true"]
    stcli.main()

if __name__ == "__main__":
    try:
        main()
    except Exception:
        import traceback
        traceback.print_exc()
        input("\nHiba tortent. Enter a kilepeshez...")
        raise
