# -*- mode: python ; coding: utf-8 -*-
from PyInstaller.utils.hooks import collect_all, collect_submodules, copy_metadata
from pathlib import Path

base = Path(SPECPATH)
datas = [(str(base / n), '.') for n in ['app.py','parser.py','tvp.py','combat.py','obsidian_theme.py']]
datas += [(str(base / '.streamlit'), '.streamlit')]
binaries = []
hiddenimports = []
for package in ['streamlit', 'plotly', 'altair', 'pyarrow']:
    d, b, h = collect_all(package)
    datas += d
    binaries += b
    hiddenimports += h
for package in ['pandas', 'bs4']:
    hiddenimports += collect_submodules(package)
for package in ['streamlit', 'plotly', 'altair', 'pyarrow']:
    datas += copy_metadata(package)

a = Analysis(['launcher.py'], pathex=[str(base)], binaries=binaries,
             datas=datas, hiddenimports=hiddenimports, hookspath=[],
             hooksconfig={}, runtime_hooks=[], excludes=['tkinter','matplotlib','pytest'],
             noarchive=False)
pyz = PYZ(a.pure)
exe = EXE(pyz, a.scripts, [], exclude_binaries=True, name='TF_Analyzer',
          debug=False, bootloader_ignore_signals=False, strip=False,
          upx=False, console=True, disable_windowed_traceback=False)
coll = COLLECT(exe, a.binaries, a.datas, strip=False, upx=False,
               name='TF_Analyzer_0_6_4_Windows')
