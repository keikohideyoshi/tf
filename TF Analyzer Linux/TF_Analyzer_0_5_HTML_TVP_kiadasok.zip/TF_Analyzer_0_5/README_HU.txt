TF ANALYZER 0.5 – HTML-ALAPÚ TVP-KIADÁSOK PARANCSKÓDONKÉNT
=========================================================

ÚJDONSÁG A 0.4.3-HOZ KÉPEST
- A tvpkolt elemtől a HTML dokumentumban visszafelé megkeressük a
  legelső <td width="250"> cellát. A cella első szóközzel elválasztott,
  nem számmal kezdődő tokenje a parancskód.
- Például: <td width="250">tf 3 10 0</td> -> TF.
- A TVP-kiadások grafikonján és összesítésében kizárólag a parancskód
  szerepel, a paraméterek nem alkotnak külön kategóriát.
- A tételes napló Parancs oszlopában a teljes parancssor látható.
- Ha a megfelelő parancscella nem található vagy nem értelmezhető,
  a kategória Ismeretlen; nem találgatunk.
- A TVP-bevételek korábbi felismerése változatlan (0.4.3).
- A harci modul combat.py fájlja változatlan (0.3.3).
- Az adatbázis szerkezete változatlan, újraimportálás nem szükséges.

FRISSÍTÉS ENDEAVOUROS / ARCH + i3 KÖRNYEZETBEN
1. A futó programot állítsd le a terminálban Ctrl+C-vel.
2. Mentsd el a jelenlegi programkönyvtárat, különösen a
   tf_analyzer.sqlite3 adatbázist.
3. Csomagold ki a ZIP-et. A TF_Analyzer_0_5 mappa fájljait másold
   át a jelenlegi TF_Analyzer mappádba, a programfájlokat felülírva.
4. NE töröld és NE írd felül a tf_analyzer.sqlite3 adatbázist.
5. A szokásos programkönyvtárban futtasd: ./inditas.sh
6. Firefoxban: http://localhost:8501
7. A TVP fülön ellenőrizd a Kategória és Parancs oszlopokat.

MEGJEGYZÉS
A HTML-parancskód a ténylegesen megelőző cellából származik;
érdemes a ritka, szokatlan parancskódokat manuálisan ellenőrizni.
A tvpkolt szövegének felismerésén nem változtattunk: az eltérő
szövegformátumú tvpkolt elemek továbbra is ellenőrzést igényelhetnek.
